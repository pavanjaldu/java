app.controller("mycontroller",function($scope,$http){
	$scope.getCategories=function(){
		var url="http://localhost:8080/projectManagementSystem1/JsonServlet?action=category";
		$http.get(url)
					.success(function(response){
						$scope.categories=response;
					})
					.error(function(msg){
						$scope.categories=msg;
					});
	
	};
	
	
	$scope.getsubcategories=function(){
		var url="http://localhost:8080/projectManagementSystem1/JsonServlet?action=subcategory";
		$http.get(url)
					.success(function(response){
						$scope.subcategories=response;
					})
					.error(function(msg){
						$scope.subcategories=msg;
					});
	
	};
	
	$scope.getsuppliers=function(){
		var url="http://localhost:8080/projectManagementSystem1/JsonServlet?action=supplier";
		$http.get(url)
					.success(function(response){
						$scope.suppliers=response;
					})
					.error(function(msg){
						$scope.suppliers=msg;
					});
	
	};
	$scope.getdiscounts=function(){
		var url="http://localhost:8080/projectManagementSystem1/JsonServlet?action=discount";
		$http.get(url)
					.success(function(response){
						$scope.discounts=response;
					})
					.error(function(msg){
						$scope.discounts=msg;
					});
	
	};
			
});