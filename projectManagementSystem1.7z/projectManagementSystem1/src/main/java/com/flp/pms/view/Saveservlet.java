package com.flp.pms.view;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Saveservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter();
		String productName=request.getParameter("pname");
		String proddesc=request.getParameter("pdes");
		String manfacDate=request.getParameter("pmafdate");
		String expDate=request.getParameter("pexdate");
		String mrp=request.getParameter("mrp");
		String catName=request.getParameter("cat");
		String subcatName=request.getParameter("subcat");
		
	}

}
