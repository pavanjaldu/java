package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForJdbc;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class ProductServiceImpl implements IProductService {
	 IProductDao iProductDao=new ProductDaoImplForJdbc();
	


	@Override
	public List<Category> getAllCategory() {
		
		 return iProductDao.getAllCategory();
	}

	@Override
	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	@Override
	public List<Supplier> getAllSuppliers() {
		return iProductDao.getAllSuppliers();
	}

	@Override
	public List<Discount> getAllDiscounts() {
		return iProductDao.getAllDiscounts();
	}

	@Override
	public void addProduct(Product product) {
		iProductDao.addProduct(product);
		
	}

	@Override
	public Map<Integer, Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> viewAllProductList() {
		return iProductDao.viewAllProductList();
	}

	@Override
	public Product search_By_Name(String productName) {
		List<Product> productlist=viewAllProductList();
		Product pro=new Product();
		for(Product p:productlist){
			if(p.getProduct_Name().equalsIgnoreCase(productName)){
				pro=p;
			}
		}
		return pro;
	}

	@Override
	public List<Product> search_By_SupplierName(String suppiler_Name) {
		List<Product> porductlist=new ArrayList<>();
		List<Product> listproduct=viewAllProductList();
		for(Product pro:listproduct){
			if(pro.getSupplier().getFirst_Name().equalsIgnoreCase(suppiler_Name)){
				porductlist.add(pro);
				
			}
		}
		return porductlist;
	}

	@Override
	public List<Product> search_By_CtaegoryName(String category_Name) {
		List<Product> productlist=new ArrayList<>();
		List<Product> listproduct=viewAllProductList();
		for(Product pro:listproduct){
			if(pro.getCategory().getCategory_Name().equalsIgnoreCase(category_Name)){
				productlist.add(pro);
				
			}
		}
		return productlist;
	}

	@Override
	public List<Product> search_By_SubCategoryName(String Subcategory_Name) {
		List<Product> productlist=new ArrayList<>();
		List<Product> listproduct=viewAllProductList();
		for(Product pro:listproduct){
			if(pro.getSubCategory().getSubCategory_Name().equalsIgnoreCase(Subcategory_Name)){
				productlist.add(pro);
			
			}
			
		}
		return productlist;
	}

	@Override
	public List<Product> search_By_Rating(int rating) {
		List<Product> list_product=new ArrayList<Product>();
		List<Product> productlist=viewAllProductList();
		for(Product pro:productlist){
			if(pro.getRating()==rating){
				list_product.add(pro);
			}
		}
		return productlist;
	}

	@Override
	public Product search_By_ProductId(int product_Id) {
		Product p=null;
		List<Product> listproduct=viewAllProductList();
		for(Product pro:listproduct){
			if(pro.getProduct_Id()==product_Id)
				p=pro;
		}
		return p;
	}

	@Override
	public void updateProductName(Product product, String productName) {
		iProductDao.updateProductName(product, productName);
		
	}

	@Override
	public void updateExpiryDate(Product product, Date expiry_date) {
		iProductDao.updateExpiryDate(product,expiry_date);
		
	}

	@Override
	public void updateMaxRetailPrice(Product product, double mrp) {
		iProductDao.updateMaxRetailPrice(product,mrp);
		
	}

	@Override
	public void updateRating(Product product, float rating) {
		iProductDao.updateRating(product,rating);
		
	}

	@Override
	public void updateCategory(Product product, Category category) {
		iProductDao.updateCategory(product,category);
		
	}

	@Override
	public void deleteProduct(int product_Id) {
		iProductDao.deleteProduct(product_Id);
		
	}

}
