app.controller("myCtrl",function($scope,$http){
	$scope.getProducts= function (){
	var url='http://localhost:8080/ProductManagementSystem-Web/ViewAllServlet';
	$http.get(url)
		.success(function(response){
			$scope.products1=response;
		})
		.error(function(msg){
			$scope.products1=msg;
		});
	};
		$scope.getCategories= function (){
		var url='http://localhost:8080/ProductManagementSystem-Web/CategoryServlet';
		$http.get(url)
			.success(function(response){
				$scope.products=response;
			})
			.error(function(msg){
				$scope.products=msg;
			});
		};
		$scope.getSuppliers= function (){
			var url='http://localhost:8080/ProductManagementSystem-Web/SupplierServlet';
			$http.get(url)
				.success(function(response){
					$scope.suppliers=response;
				})
				.error(function(msg){
					$scope.suppliers=msg;
				});
			};
			$scope.getSubCategories= function (){
				var url='http://localhost:8080/ProductManagementSystem-Web/SubCategoryServlet';
				$http.get(url)
					.success(function(response){
						$scope.SubCategories=response;
					})
					.error(function(msg){
						$scope.SubCategories=msg;
					});
				};
				$scope.getdiscounts= function (){
					var url='http://localhost:8080/ProductManagementSystem-Web/DiscountServlet';
					$http.get(url)
						.success(function(response){
							$scope.discounts=response;
						})
						.error(function(msg){
							$scope.discounts=msg;
						});
					};
      });

	
	
