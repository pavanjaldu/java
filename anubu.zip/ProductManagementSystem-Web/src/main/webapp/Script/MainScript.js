function prodValidation() {
	var flag = false;
	var prodName = prodForm.pname.value;
	var prodDesc = prodForm.pdesc.value;
	var prodMRP = prodForm.mrp.value;
	var today = "06/18/2016";
	var manudate = prodForm.manuDate.value;
	var exDate = prodForm.exDate.value;
	var quantity = prodForm.quantity.value;
	var rating = prodForm.rating.value;
	
	if (prodName == '') {

		document.getElementById('prodNameMsg').innerHTML = '*Please enter Product name.';

	} else {
		document.getElementById('prodNameMsg').innerHTML = '';
		if (prodDesc == '') {

			document.getElementById('prodDiscMsg').innerHTML = '*Please enter Product Description.';

		} else {
			document.getElementById('prodDiscMsg').innerHTML = '';	
			if (prodMRP == '') {

				document.getElementById('prodMRPMsg').innerHTML = '*Please enter Product MRP.';

			} else {
				document.getElementById('prodMRPMsg').innerHTML = '';	
				if (manudate < today) {
					document.getElementById('prodManuDate').innerHTML = '*Manufacturing date should be a past date';
				} else {
					document.getElementById('prodManuDate').innerHTML = '';	
					if (exDate < today) {
						document.getElementById('prodEXpDate').innerHTML = '*Manufacturing date should be a future date';
					} else {
						document.getElementById('prodEXpDate').innerHTML = '';		
					if (quantity == '') {

						document.getElementById('QuanMsg').innerHTML = '*Please enter Product Quantity.';

					} else {
						document.getElementById('QuanMsg').innerHTML = '';	
						if (rating == '') {

							document.getElementById('RatMsg').innerHTML = '*Please enter Product Rating.';

						} else {
							document.getElementById('RatMsg').innerHTML = '';	
		flag = true;
	}
	}
	}
	}
			}
		}
	}

	return flag;
}

