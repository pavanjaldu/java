package com.cap.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	String pname=request.getParameter("pname");
	String pdesc=request.getParameter("pdesc");
	String mrp=request.getParameter("mrp");
	double mrp1=Double.parseDouble(mrp);
	String manuDate=request.getParameter("manuDate");
	String exDate=request.getParameter("exDate");
	String ptype=request.getParameter("ptype");
	int cat=Integer.parseInt(ptype);
	String Subtype=request.getParameter("Subtype");
	int sub=Integer.parseInt(Subtype);
	String stype=request.getParameter("stype");
	int sup=Integer.parseInt(stype);
	String[] discountType=request.getParameterValues("discountType");
	String quantity=request.getParameter("quantity");
	int quantity1=Integer.parseInt(quantity);
	String rating=request.getParameter("rating");
	float rating1=Float.parseFloat(rating);
	Product product=new Product();
	product.setProductName(pname);
	product.setDescription(pdesc);
	product.setMax_retail_price(mrp1);
	IProductDao iProductDao=new ProductDaoImplForMap();
	SimpleDateFormat myformat=new SimpleDateFormat("yyyy-mm-dd");
	
	try {
		product.setManufacturing_date(myformat.parse(manuDate));
		product.setExpiry_date(myformat.parse(exDate));
	} catch (ParseException e) {
		e.printStackTrace();
	}
	Category category=new Category();
	category.setCategory_Id(cat);
	product.setCategory(category);
	SubCategory subCategory=new SubCategory();
	subCategory.setSub_category_Id(sub);
	product.setSubCategory(subCategory);
	
	Supplier supplier=new Supplier();
	supplier.setSupplierId(sup);
	product.setSupplier(supplier);
	product.setQuantity(quantity1);
	product.setRatings(rating1);
	List<Discount> discounts2=iProductDao.getAllDiscounts();
	List<Discount> discounts3=new ArrayList<>();
	int len=discountType.length;
	int i=0;
	for(Discount dis1:discounts2){
		if(i<len){
		if(dis1.getDiscountName().equalsIgnoreCase(discountType[i])){
			discounts3.add(dis1);
			i++;
		}
		}
	product.setDiscounts(discounts3);
	}
	iProductDao.addProduct(product);
	response.sendRedirect("pages/Success.html");
	}
	
		
	
}

