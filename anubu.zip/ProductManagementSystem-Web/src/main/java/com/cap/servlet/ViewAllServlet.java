package com.cap.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;

import com.flp.pms.domain.Product;
import com.google.gson.Gson;

public class ViewAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    response.setContentType("application/json");
		
		PrintWriter out=response.getWriter();
		
		IProductDao iProductDao=new ProductDaoImplForMap();
		
		List<Product> products=iProductDao.getAllProducts1();
		
		Gson myJson=new Gson();
		
		String productjson=myJson.toJson(products);
		
		out.println(productjson);
			
		
		
		
		
		
}
}
