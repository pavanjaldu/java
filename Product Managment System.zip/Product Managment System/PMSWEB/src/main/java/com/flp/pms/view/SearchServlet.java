package com.flp.pms.view;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Gson myjson=new Gson();
		
	
		IProductService iProductService=new ProductServiceImpl();
		

		String searchBy=request.getParameter("searchBy");
		String searchtype=request.getParameter("searchtype");
		System.out.println(searchBy);
		System.out.println(searchtype);
		//if(action.equalsIgnoreCase("Name")){
		if(searchBy.equalsIgnoreCase("search by Name")){
			Product product=iProductService.search_By_Name(searchtype);
			response.setContentType("application/json");
			String namejson=myjson.toJson(product);
	
			
			iProductService.storeJsonData(namejson);
			response.sendRedirect("pages/DisplayProduct.html");
		}
		else if(searchBy.equalsIgnoreCase("search By Supplier Name")){
			System.out.println(searchBy);
			List<Product> products=iProductService.search_By_SupplierName(searchtype);
			response.setContentType("application/json");
			String supNamelist=myjson.toJson(products);
			System.out.println(supNamelist);
			iProductService.storeJsonData(supNamelist);
			response.sendRedirect("pages/DisplayProductList.html");
			
		}else if(searchBy.equalsIgnoreCase("search by Category Name")){
			List<Product> products=iProductService.search_By_CtaegoryName(searchtype);
			response.setContentType("application/json");
			String catnamelist=myjson.toJson(products);
			iProductService.storeJsonData(catnamelist);
			response.sendRedirect("pages/DisplayProductList.html");
		}
		else if(searchBy.equalsIgnoreCase("search by sub Category Name")){
			List<Product> products=iProductService.search_By_SubCategoryName(searchtype);
			response.setContentType("application/json");
			String subcatnamelist=myjson.toJson(products);
			iProductService.storeJsonData(subcatnamelist);
			response.sendRedirect("pages/DisplayProductList.html");
		}else if(searchBy.equalsIgnoreCase("search by Rating")){
			List<Product> products=iProductService.search_By_Rating(Float.parseFloat(searchtype));
			response.setContentType("application/json");
			String ratinglist=myjson.toJson(products);
			iProductService.storeJsonData(ratinglist);
			response.sendRedirect("pages/DisplayProductList.html");
		}
		
	}

}
