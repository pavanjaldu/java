package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		Product product=new Product();
		IProductService iproductservice=new ProductServiceImpl();
		int id=Integer.parseInt(request.getParameter("pid"));
		String name=request.getParameter("cat");
		String field=request.getParameter("update");
		product.setProduct_Id(id);
		boolean flag=false;
		if(name.equals("productName"))
		{
			//product.setProduct_Name(field);
			iproductservice.updateProductName(product, field);
			/*flag=iProductService.addProduct(product);
			 if(flag){
				 response.sendRedirect("pages/success.html");
			 }else
				 response.sendRedirect("pages/error.html");*/
		}
		else if(name.equals("expiryDate"))
		{
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date mdate;
			try {
			  mdate=sdf.parse(field);
			  iproductservice.updateExpiryDate(product, mdate);
			} 
			catch (ParseException e)
			{
				e.printStackTrace();
			}
		}
		else if(name.equals("mrp"))
		{
			//Float price=Float.parseFloat(field);
			Double price=Double.parseDouble(field);
			iproductservice.updateMaxRetailPrice(product, price);
		}
		else if(name.equals("rating"))
		{
			float rat=Float.parseFloat(field);
			iproductservice.updateRating(product, rat);
		}
		else if(name.equals("category"))
		{
			
		}
		//out.println(id+ "  "+ name+" "+field);
	}

}
