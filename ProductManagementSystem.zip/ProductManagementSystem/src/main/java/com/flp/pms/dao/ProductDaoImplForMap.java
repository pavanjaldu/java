package com.flp.pms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.xml.datatype.DatatypeConfigurationException;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.mysql.jdbc.Statement;

public class ProductDaoImplForMap implements IProductDao
{

	HashMap<Integer,Product> hashmap=new HashMap<Integer,Product>();
	
	Connection conn=null;
	
	
	public List<Category> chooseCategory()
	{
		
		
	    conn=getMySqlConnection();
		
	    List<Category> catogeries=new ArrayList<Category>();
		
	    String sql="select * from category";
	    
	    try
	    {
			PreparedStatement pstm=conn.prepareStatement(sql);
			
			ResultSet rs=pstm.executeQuery();
			
			while(rs.next())
			{				
				catogeries.add(new Category(rs.getInt(1),rs.getString(2), rs.getString(3)));
			}
			
			System.out.println("size of category list : "+catogeries.size());
			
		} 
	    catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return catogeries;
	}
	
	public List<SubCategory> choose_SUBCategory()
	{
		
		  conn=getMySqlConnection();
		
		List<SubCategory> subcatogerieslist=new ArrayList<SubCategory>();
		
		
		String sql1="SELECT * FROM sub_category";
		
		
		
		try 
		{
			PreparedStatement pstmt1=conn.prepareStatement(sql1);
			
						
			ResultSet rs1=pstmt1.executeQuery();
			
			
			
			while(rs1.next())
			{

				Category category=new Category();
				
				category.setCategory_ID(rs1.getInt(3));
				
			 subcatogerieslist.add(new SubCategory(rs1.getInt(1),rs1.getString(2) ,category));
				
			}
			
			//System.out.println("size of sub-category :"+subcatogerieslist.size());
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		
		
		
		
		
		/*SubCategory subcategory11=new SubCategory(101, "MOBILES",new Category(1,"ELECTRONICS", "MOBILES & LAPTOPS"));
		SubCategory subcategory12=new SubCategory(102, "LAPTOPS", new Category(1,"ELECTRONICS", "MOBILES & LAPTOPS"));
		SubCategory subcategory13=new SubCategory(103, "LED TV's AND REFRIGRATORS", new Category(1,"ELECTRONICS", "MOBILES & LAPTOPS"));
		
		
		SubCategory subcategory21=new SubCategory(201,"CRICKET KIT" ,new Category(2,"SPORTS", "FOOTBALL & CRICKET KITS"));
		SubCategory subcategory22=new SubCategory(202,"FOOTBALLS" , new Category(2,"SPORTS", "FOOTBALL & CRICKET KITS"));
		SubCategory subcategory23=new SubCategory(203,"GOLF KITS" , new Category(2,"SPORTS", "FOOTBALL & CRICKET KITS"));
		
		
		SubCategory subcategory31=new SubCategory(301, "FACE WASH", new Category(3,"BEAUTY and FAIRNESS", "BEAUTY PRODUCTS and SKIN PRODUCTS"));
		SubCategory subcategory32=new SubCategory(302, "FAIRNESS CREAM", new Category(3,"BEAUTY and FAIRNESS", "BEAUTY PRODUCTS and SKIN PRODUCTS"));
		SubCategory subcategory33=new SubCategory(303,"HAIR OIL" , new Category(3,"BEAUTY and FAIRNESS", "BEAUTY PRODUCTS and SKIN PRODUCTS"));
		
		SubCategory subcategory41=new SubCategory(401, "JAVA BOOK BY SARATH", new Category(4,"ACADEMIC BOOKS AND NOVELS ", "LATEST RELEASED NOVELS AND REFERENCE BOOKS"));
		SubCategory subcategory42=new SubCategory(402, "C&JAVA BOOK BY SIVA",new Category(4,"ACADEMIC BOOKS AND NOVELS ", "LATEST RELEASED NOVELS AND REFERENCE BOOKS"));
		SubCategory subcategory43=new SubCategory(403, "C,C++ AND JAVA Book BY PRASAD", new Category(4,"ACADEMIC BOOKS AND NOVELS ", "LATEST RELEASED NOVELS AND REFERENCE BOOKS"));
		
			
		SubCategory subcategory51=new SubCategory(501,"THERMOMETER", new Category(5,"HEALTH", "HEALTH RELATED PRODUCTS"));
		SubCategory subcategory52=new SubCategory(502,"NEBULIZER" ,new Category(5,"HEALTH", "HEALTH RELATED PRODUCTS"));
		SubCategory subcategory53=new SubCategory(503,"WALKER", new Category(5,"HEALTH", "HEALTH RELATED PRODUCTS"));*/
		
		/*subcatogerieslist.add(subcategory11);
		subcatogerieslist.add(subcategory12);
		subcatogerieslist.add(subcategory13);
		
		subcatogerieslist.add(subcategory21);
		subcatogerieslist.add(subcategory22);
		subcatogerieslist.add(subcategory23);
		
		subcatogerieslist.add(subcategory31);
		subcatogerieslist.add(subcategory32);
		subcatogerieslist.add(subcategory33);
		
		subcatogerieslist.add(subcategory41);
		subcatogerieslist.add(subcategory42);
		subcatogerieslist.add(subcategory43);
		
		subcatogerieslist.add(subcategory51);
		subcatogerieslist.add(subcategory52);
		subcatogerieslist.add(subcategory53);*/
		
		
		return subcatogerieslist;
	}
	
	
	public List<Discount> discountForProduct()
	{
		
		//SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		
		  conn=getMySqlConnection();
		
		List<Discount> discountlist=new ArrayList<Discount>();
		
		
		String sql="SELECT * FROM discount";
		
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			
			ResultSet rs=pstmt.executeQuery();
		
			while(rs.next())
			{
			
			discountlist.add(new Discount(rs.getInt(1), rs.getString(2),rs.getString(3), rs.getDouble(4), rs.getDate(5)));
			}
			
			//System.out.println("discountlist"+discountlist.size());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		
		
		/*String date1="01/05/2004";
		String date2="01/03/2013";
		String date3="01/11/2015";
		String date4="01/12/2007";
		String date5="01/01/2009";
		
		
		Discount discount1=new Discount(1103, "New Year Megasale", "Grab offer for New Year", 20.0, new Date(date1));
		Discount discount2=new Discount(1104, "Sankranti Celebrations", "Sankranti  offer as Never Before", 30.0, new Date(date2));
		Discount discount3=new Discount(1105, "Vinaya Chaturti Offer", "Celebration starts Big", 14.60, new Date(date3));
		Discount discount4=new Discount(1106, "EID", "EID Mubarak Special", 12.5, new Date(date4));
		Discount discount5=new Discount(1107, "Christmas", "Santa offers are always Good!", 5.36, new Date(date5));
		
		discountlist.add(discount1);
		discountlist.add(discount2);
		discountlist.add(discount3);
		discountlist.add(discount4);
		discountlist.add(discount5);
		*/
		return discountlist;
	}

	public List<Supplier> supplierForProduct()
	{
		
		  conn=getMySqlConnection();
		
		List<Supplier> listsupplier=new ArrayList<Supplier>();
		
		String sql="SELECT * FROM supplier";
		
		
		try 
		{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				listsupplier.add(new Supplier(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5), rs.getString(6),rs.getString(7),rs.getString(8)));
			}
			
			//System.out.println("listsupplier"+listsupplier.size());
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		
		
		
		/*
		Supplier supplier1=new Supplier(2001,"Harish","Racherla","H.No 2-1-127,Venkateshwara Colony", "Hyderabad", "Telangana","500068","9490214980");
		Supplier supplier2=new Supplier(2002,"Kohli","Virat","H.No 1-2-22,Seven Hills", "Amaravati", "AndhraPradesh","300022","9652221938");
		Supplier supplier3=new Supplier(2003,"David","Warner","H.No 4-2-12,Huda Colony", "Banglore", "Karnataka","400034","8886308296");
		Supplier supplier4=new Supplier(2004,"Mahendra Singh","Dhoni","Plot No. 127,Co-operative Bank Colony", "Ranchi", "JharKhand","600012","8330950822");
		Supplier supplier5=new Supplier(2005,"Sachin","Tendulkar","Flat No 106,Hanuman Nagar", "Mumbai", "Maharastra","700010","9052884995");
	
		listsupplier.add(supplier1);
		listsupplier.add(supplier2);
		listsupplier.add(supplier3);
		listsupplier.add(supplier4);
		listsupplier.add(supplier5);*/
	
		return listsupplier;
	}
	
	
	
	
	
	public void insertionOfProduct(Product product)
	{
		
		
		
		 conn=getMySqlConnection();
		
		int prod_Id=0;
		
		String sql="insert into product(prod_Name,prod_decription,maufac_date,expiry_date,maximum_retailprice,categ_id,sub_categry_id,supplirId,prod_Quanty,prod_rating) values(?,?,?,?,?,?,?,?,?,?)  ";
		
		PreparedStatement pstmt=null;
		Statement stmt=null;
		//String sql1="insert into product_discount(discount) values(?)";
		try
		{
			
			
		
			pstmt=conn.prepareStatement(sql);
			
			//PreparedStatement pstmt1=conn.prepareStatement(sql1);
			
			//PreparedStatement pstmt1=conn.prepareStatement(sql1);
			
			//pstmt.setInt(1,product.getProduct_ID());
			
			pstmt.setString(1,product.getProduct_Name() );
			pstmt.setString(2, product.getProduct_Description());
			pstmt.setDate(3, new Date(product.getManufacturing_Date().getTime()) );
			pstmt.setDate(4, new Date(product.getExpiry_Date().getTime()));
			pstmt.setDouble(5, product.getProduct_maximum_RetailPrice());
			pstmt.setInt(6,product.getProduct_category().getCategory_ID());
			pstmt.setInt(7, product.getProduct_Subcategory().getSub_category_ID());
			pstmt.setInt(8, product.getProduct_Supplier().getSupplier_ID());
			pstmt.setInt(9,product.getProduct_Quantity() );
			pstmt.setFloat(10, product.getProduct_Rating());
			
			
			int rows=pstmt.executeUpdate();
			
			/*for(Discount discont:discountList)
			{
					pstmt1.setInt(1, discont.getDiscount_ID());
					int rows1=pstmt1.executeUpdate();
			}*/
			
			System.out.println(" Rows effected are  : "+rows);
			
		if(rows>0)
		{			
			String sql1="SELECT prod_Id FROM product ORDER BY prod_Id ASC";
			
			
			int prod_IdCount=0;
			
           
           pstmt=conn.prepareStatement(sql1);
           
			ResultSet rs=pstmt.executeQuery();
			
			rs.last();
			prod_IdCount=rs.getInt(1);
			
			
			/*System.out.println("Rows count :"+rs.getRow());
			
			if(rs.getRow()==1)
			{
				while(rs.next())
					prod_IdCount=rs.getInt(1);
			}
			else if(rs.getRow()>1)
			{
			for(int i=1;i<=rs.getRow();i++)
			{
			 rs.next();
			 prod_IdCount=rs.getInt(1);			
			}
			}*/
			
			
			List<Discount> discountList=product.getProduct_Discount();	
			
			
			
			System.out.println(" prod_IdCount "+prod_IdCount);
			
			String sql2="INSERT INTO product_discount(product_id,discount_id) VALUES(?,?)"; 
			
			for(Discount dict:discountList)
			{
				
				System.out.println(dict.getDiscount_ID());
				pstmt=conn.prepareStatement(sql2);
				
				pstmt.setInt(1,prod_IdCount);
				pstmt.setInt(2,dict.getDiscount_ID() );
				
				int prod_discount_table=pstmt.executeUpdate();
				
				if(prod_discount_table>0)
					System.out.println("Successful");
				
			}
			
			//String sql2=""
			
			//System.out.println(" Record Inserted Successfully. ");
		
			//String sql1="select  product_discount values(?,?)  ";
			
			//PreparedStatement pstmt1=conn.prepareStatement(sql);
			
			//pstmt1.setInt(1, );
		
		
		
		}
		
			
			/*String sql1="insert into product_discount values(?,?)  ";
			
			
			for(Discount discnt:discountList)
			{
				pstmt1.setInt(1, product.getProduct_ID());
				pstmt1.setInt(2, discnt.getDiscount_ID());
				
			}	
			*/
			
		} 
		catch (SQLException e)
		{
				e.printStackTrace();
		}
		
		//hashmap.put(product.getProduct_ID(), product);
		
		
	}
	
	public HashMap<Integer,Product> sendingMaptoServiceProduct()
	{
		
		
		return this.hashmap;
		
	}
	
	
	 public Product modifyingProductFromDatabase(int productId)
	 {
		 Statement stmt=null;
		 Product prodObj=null;
		 PreparedStatement pstmtId=null;
		 //System.out.println("In Dao Impl"+productId);
		
		 List<Discount> productList=new ArrayList<Discount>();
		 
		 conn= getMySqlConnection();
		
		
		 try
		 {
			 
			 PreparedStatement pstmtDiscount=null;
			 
			 String Idsql="SELECT * FROM product WHERE prod_Id=?";
			 
			// Discount discount=new Discount();
			 
			 prodObj=new Product(); 
			
			 pstmtId=conn.prepareStatement(Idsql);
			
			 // Setting For Id 
			 pstmtId.setInt(1,productId);
			
			 ResultSet rs=pstmtId.executeQuery();
						
			while(rs.next())
			{
				Category category1=new Category();
				SubCategory subcategory=new SubCategory();
				Supplier supplier=new Supplier();
				
				prodObj.setProduct_Name(rs.getString(2));
				prodObj.setProduct_Description(rs.getString(3));
				prodObj.setManufacturing_Date(rs.getDate(4));
				prodObj.setExpiry_Date(rs.getDate(5));
				prodObj.setProduct_maximum_RetailPrice(rs.getDouble(6));
				
				category1.setCategory_ID(rs.getInt(7));
				prodObj.setProduct_category(category1);
				subcategory.setSub_category_ID(rs.getInt(8));
				prodObj.setProduct_Subcategory(subcategory);
				supplier.setSupplier_ID(rs.getInt(9));
				//System.out.println(prodObj.getProduct_Supplier().getSupplier_ID());
				prodObj.setProduct_Supplier(supplier);
				prodObj.setProduct_Quantity(rs.getInt(10));
				prodObj.setProduct_Rating(rs.getFloat(11));
			
			
			}
			
			//Setting Discount 
			String discountSql="SELECT product_id,discount_id FROM product_discount WHERE product_id=?";
			
			pstmtDiscount=conn.prepareStatement(discountSql);
			
			//Setting For Discount
			pstmtDiscount.setInt(1,productId);
			
			ResultSet rsdiscount=pstmtDiscount.executeQuery();
			
			while(rsdiscount.next())
			{
			Discount discount=new Discount();	
			discount.setDiscount_ID(rsdiscount.getInt(2));
			//System.out.println("Discount ID is "+rsdiscount.getInt(2));
			productList.add(discount);
			}
			
			
			//System.out.println(productList);
			
			//Iterator<Discount> it=productList.iterator();
			
		/*	while(it.hasNext())
			{
				System.out.println(it.next().getDiscount_ID());
			}*/
			
			
			/*for(Discount discountprod:productList)
			{
				System.out.println(" Discount Id "+discountprod.getDiscount_ID());
			}*/
			
			prodObj.setProduct_Discount(productList);
		}
		 catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		 
		//Set<Integer> prod_keys=hashmap.keySet();
		
		//Iterator it=prod_keys.iterator();
		
		/*while(it.hasNext())
		{
		if(productId==(Integer)it.next())
		{
			System.out.println(" Invalid Product ID ! Does not Exist in our DataBase. ");
		}
		else
		{
		prodObj=(Product)hashmap.get(productId);
		}			
	    }*/		
		 return prodObj;
	 }
	
	
	 public void insertionIntoDataBaseAfterUpdate(int prod_Id,Product updproduct)
     {
		 
		 hashmap.put(prod_Id,updproduct);
		 
     }

	public boolean deleteProductFromDataBase(int prod_Id) 
	{
		conn=getMySqlConnection();
		
		try
		{

			String sqlDeleteProduct="DELETE FROM product_discount WHERE product_id=?";
			
			PreparedStatement ptsmtdelete=conn.prepareStatement(sqlDeleteProduct);
			
			ptsmtdelete.setInt(1,prod_Id);
						
			int prodDelete=ptsmtdelete.executeUpdate();
			
			System.out.println("prodDelete outer if "+prodDelete);
			
			if(prodDelete>0)
			{
				System.out.println(" Delete from table Parent ");
				String sqlDeleteProductTable="DELETE FROM product WHERE prod_id=?";
				
				PreparedStatement ptsmtdeleteTable=conn.prepareStatement(sqlDeleteProductTable);
				
				ptsmtdeleteTable.setInt(1,prod_Id);
							
				int productDeleteParentTable=ptsmtdeleteTable.executeUpdate();
				
				System.out.println(" productDeleteParentTable ==="+productDeleteParentTable);
				
				if(productDeleteParentTable>0)
				{
					System.out.println("prodDelete inner if"+productDeleteParentTable);
					return true;
				}
				
			}
			
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;
		
		
		
		
		//hashmap.remove(prod_Id);
	}
    
	
	
	//SQL Connection Created
	public Connection getMySqlConnection()
	{
		
		
		
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/productmanagementsystem", "root","India123");
		}
		catch (ClassNotFoundException e)
		{
				e.printStackTrace();
		} catch (SQLException e)
		{
				e.printStackTrace();
		}
		
			
		
		return conn;
	}
	
	
	public int[] dataBaseLogicForComparisionId()
	{
		int rowCount = 0;
		ResultSet rs=null;
		int[] arrayId=null;
		String sqlstmt="SELECT prod_Id FROM product";
		
		conn=getMySqlConnection();
		
		Statement stmt;
		try
		{
			stmt = (Statement) conn.createStatement();
			rs = stmt.executeQuery(sqlstmt);
			
			//Getting Number of rows in DataBase
			
			while ( rs.next() )
			{
			   rowCount++;
			}
						
			 arrayId=new int[rowCount];
			 
			 rs.first();
			 for(int i=0;i<arrayId.length;i++)
			 {
				 if(i==0)
				 {
					 arrayId[i]=rs.getInt(1);	 
				 }
				 else
				 {
				  rs.next();
				  arrayId[i]=rs.getInt(1);
				 }
				 
			 }
			 
			 
		}
		catch (SQLException e1) 
		{
			
			e1.printStackTrace();
		}
		
		
		
		return arrayId;
	}
	
	
	public boolean nameUpdate(String nameUpdate,int prodId)
	{
		
		String sqlNameUpdate="UPDATE product SET prod_Name=? WHERE prod_Id=?";
		
		conn=getMySqlConnection();
		
		try 
		{
			PreparedStatement ptsmt=conn.prepareStatement(sqlNameUpdate);
			
			ptsmt.setString(1,nameUpdate);
			ptsmt.setInt(2,prodId);
			
			int nameupdated=ptsmt.executeUpdate();
			
			if(nameupdated>0)
					return true;
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean productDescriptionUpdate(String descUpdate,int prodId)
	{
		
		String sqldescUpdate="UPDATE product SET prod_decription=? WHERE prod_Id=?";
		
		conn=getMySqlConnection();
		
		try
		{
			PreparedStatement ptsmtdesc=conn.prepareStatement(sqldescUpdate);
			
			ptsmtdesc.setString(1,descUpdate);
			ptsmtdesc.setInt(2,prodId);
			
			int descupdated=ptsmtdesc.executeUpdate();
			
			if(descupdated>0)
			{
				System.out.println(" Updated successfully ");
					return true;
			}
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;
	}
	
	
	public boolean productSupplierIDUpdate(int suplUpdate,int prodId)
	{
       String sqldescUpdate="UPDATE product SET supplirId=? WHERE prod_Id=?";
		
		conn=getMySqlConnection();
		
		try
		{
			PreparedStatement ptsmt=conn.prepareStatement(sqldescUpdate);
			
			ptsmt.setInt(1,suplUpdate);
			ptsmt.setInt(2,prodId);
			
			int descupdated=ptsmt.executeUpdate();
			
			if(descupdated>0)
					return true;
			
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;
		
	}
	
	public boolean productQuantityUpdateUpdate(int productQuan,int prod_Id)
	{
         String sqlQuanUpdate="UPDATE product SET prod_Quanty=? WHERE prod_Id=?";
		
		conn=getMySqlConnection();
		
		try
		{
			PreparedStatement ptsmt=conn.prepareStatement(sqlQuanUpdate);
			
			ptsmt.setInt(1,productQuan);
			ptsmt.setInt(2,prod_Id);
			
			int quanupdated=ptsmt.executeUpdate();
			
			if(quanupdated>0)
					return true;
			
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;
		
	}
	
	
	public boolean productRatingUpdate(Float rating,int prod_id)
	{
       String sqlratingsUpdate="UPDATE product SET prod_rating=? WHERE prod_Id=?";
		
		conn=getMySqlConnection();
		
		try
		{
			PreparedStatement ptsmtrating=conn.prepareStatement(sqlratingsUpdate);
			
			ptsmtrating.setFloat(1,rating);
			ptsmtrating.setInt(2,prod_id);
			
			int ratingupdated=ptsmtrating.executeUpdate();
			
			if(ratingupdated>0)
					return true;
			
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;	
		
	}

	
	//Select From DataBase
	
	 public  List<Product> viewFromDatabase()
	 {
		 Statement stmt=null;
		 Product prodObj=null;
		 PreparedStatement pstmtId=null;
		 //System.out.println("In Dao Impl"+productId);
		
		Category category1=new Category();
		SubCategory subcategory=new SubCategory();
		Supplier supplier=new Supplier();
		
		 
		 List<Product> productListView=new ArrayList<Product>();
		 
		 List<Discount> productDiscountList=new ArrayList<Discount>();
		 
		 //List<Discount> productList=new ArrayList<Discount>();
		 
		 conn= getMySqlConnection();
		
		
		 try
		 {
			 
			 PreparedStatement pstmtview=null;
			 
			 String viewSql="SELECT * FROM product";
			 
			// Discount discount=new Discount();
			 
			
			
			 pstmtId=conn.prepareStatement(viewSql);
			
				
			 ResultSet rs=pstmtId.executeQuery();
						
			while(rs.next())
			{
				
				prodObj=new Product(); 
				
				prodObj.setProduct_ID(rs.getInt(1));
				
				String viewDiscountListSql="SELECT discount_id FROM product_discount WHERE product_id=?";
				PreparedStatement pstmtDiscount=conn.prepareStatement(viewDiscountListSql);
				pstmtDiscount.setInt(1,rs.getInt(1));
				ResultSet rsDiscount=pstmtDiscount.executeQuery();
				while(rsDiscount.next())
				{
				Discount discountView=new Discount();
				discountView.setDiscount_ID(rsDiscount.getInt(1));
				productDiscountList.add(discountView);
				}
				
				
				prodObj.setProduct_Name(rs.getString(2));
				prodObj.setProduct_Description(rs.getString(3));
				prodObj.setManufacturing_Date(rs.getDate(4));
				prodObj.setExpiry_Date(rs.getDate(5));
				prodObj.setProduct_maximum_RetailPrice(rs.getDouble(6));
				
				category1.setCategory_ID(rs.getInt(7));
				prodObj.setProduct_category(category1);
				subcategory.setSub_category_ID(rs.getInt(8));
				prodObj.setProduct_Subcategory(subcategory);
				supplier.setSupplier_ID(rs.getInt(9));
			
				//Setting List of Discount's
				prodObj.setProduct_Discount(productDiscountList);
				
				prodObj.setProduct_Supplier(supplier);
				prodObj.setProduct_Quantity(rs.getInt(10));
				prodObj.setProduct_Rating(rs.getFloat(11));
			
				productListView.add(prodObj);
			
			}
			
			
			//prodObj.setProduct_Discount(productList);
		}
		 catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		 
			
		 return productListView;
	 }
	
	
	

	public Product searchProductByName(String nameSearch)
	{
		Product productSearch=null;
		PreparedStatement pstmtGlobalSearch=null;
		
		 conn=getMySqlConnection();
		
			System.out.println(" In DAO Impl NameSearch name  "+nameSearch);
			
			try
			{
				String sqlNameSearch="SELECT * FROM product WHERE prod_Name=?" ;
				
				pstmtGlobalSearch=conn.prepareStatement(sqlNameSearch);
				pstmtGlobalSearch.setString(1,nameSearch);
				
				ResultSet rsSearchGlobal=pstmtGlobalSearch.executeQuery();
			
				System.out.println(" Hello ");
				while(rsSearchGlobal.next())
				{
					productSearch=new Product();
					
					productSearch.setProduct_ID(rsSearchGlobal.getInt(1));
					productSearch.setProduct_Name(rsSearchGlobal.getString(2));
					productSearch.setProduct_Description(rsSearchGlobal.getString(3));
					productSearch.setManufacturing_Date(rsSearchGlobal.getDate(4));
					productSearch.setManufacturing_Date(rsSearchGlobal.getDate(5));
					productSearch.setProduct_maximum_RetailPrice(rsSearchGlobal.getDouble(6));
					
					Category categoryView=new Category();
							
					categoryView.setCategory_ID(rsSearchGlobal.getInt(7));
					
					productSearch.setProduct_category(categoryView);
					
					SubCategory subcategoryView =new SubCategory();
			
					subcategoryView.setSub_category_ID(rsSearchGlobal.getInt(8));
					
					productSearch.setProduct_Subcategory(subcategoryView);
					
					Supplier supplier=new Supplier();
					
					supplier.setSupplier_ID(rsSearchGlobal.getInt(9));
					
					productSearch.setProduct_Quantity(rsSearchGlobal.getInt(10));
					
					productSearch.setProduct_Rating(rsSearchGlobal.getInt(11));
					
				}
				
				
			} 
			
			catch (SQLException e) {
				
				e.printStackTrace();
			}
		
		
		return productSearch;
	}
	
	
	
	public Product searchProductByRating(Float searchRating)
	{
		Product productSearchRating=null;
		PreparedStatement pstmtRatingSearch=null;
		
		conn=getMySqlConnection();
		
			//System.out.println(" In DAO Impl NameSearch name  "+searchRating);
			
			try
			{
				String sqlRatingSearch="SELECT * FROM product WHERE prod_rating=?" ;
				
				pstmtRatingSearch=conn.prepareStatement(sqlRatingSearch);
				pstmtRatingSearch.setDouble(1,searchRating);
				
				ResultSet rsSearchGlobal=pstmtRatingSearch.executeQuery();
			
				while(rsSearchGlobal.next())
				{
					productSearchRating=new Product();
					
					productSearchRating.setProduct_ID(rsSearchGlobal.getInt(1));
					productSearchRating.setProduct_Name(rsSearchGlobal.getString(2));
					productSearchRating.setProduct_Description(rsSearchGlobal.getString(3));
					productSearchRating.setManufacturing_Date(rsSearchGlobal.getDate(4));
					productSearchRating.setManufacturing_Date(rsSearchGlobal.getDate(5));
					productSearchRating.setProduct_maximum_RetailPrice(rsSearchGlobal.getDouble(6));
					
					Category categoryView=new Category();
							
					categoryView.setCategory_ID(rsSearchGlobal.getInt(7));
					
					productSearchRating.setProduct_category(categoryView);
					
					SubCategory subcategoryView =new SubCategory();
			
					subcategoryView.setSub_category_ID(rsSearchGlobal.getInt(8));
					
					productSearchRating.setProduct_Subcategory(subcategoryView);
					
					Supplier supplier=new Supplier();
					
					supplier.setSupplier_ID(rsSearchGlobal.getInt(9));
					
					productSearchRating.setProduct_Quantity(rsSearchGlobal.getInt(10));
					
					productSearchRating.setProduct_Rating(rsSearchGlobal.getInt(11));
					
				}
				
				
			} 
			
			catch (SQLException e) {
				
				e.printStackTrace();
			}
		
		
		return productSearchRating;
	}
	
	
	public Product searchByProducerName(String nameProducer)
	{
		
		PreparedStatement pstmtProducerNamePreparedStatement=null;
		Product productSearchProducerName=null;

		String sqlNameSearch="SELECT * FROM product WHERE supplirId=(SELECT supplier_id FROM supplier WHERE supplier_fname=?)";
		
		conn=getMySqlConnection();
		
		try
		{
			
			
			pstmtProducerNamePreparedStatement=conn.prepareStatement(sqlNameSearch);
			pstmtProducerNamePreparedStatement.setString(1,nameProducer);
			
			ResultSet rsSearchGlobal=pstmtProducerNamePreparedStatement.executeQuery();
		
			while(rsSearchGlobal.next())
			{
				productSearchProducerName=new Product();
				
				productSearchProducerName.setProduct_ID(rsSearchGlobal.getInt(1));
				productSearchProducerName.setProduct_Name(rsSearchGlobal.getString(2));
				productSearchProducerName.setProduct_Description(rsSearchGlobal.getString(3));
				productSearchProducerName.setManufacturing_Date(rsSearchGlobal.getDate(4));
				productSearchProducerName.setManufacturing_Date(rsSearchGlobal.getDate(5));
				productSearchProducerName.setProduct_maximum_RetailPrice(rsSearchGlobal.getDouble(6));
				
				Category categoryView=new Category();
						
				categoryView.setCategory_ID(rsSearchGlobal.getInt(7));
				
				productSearchProducerName.setProduct_category(categoryView);
				
				SubCategory subcategoryView =new SubCategory();
		
				subcategoryView.setSub_category_ID(rsSearchGlobal.getInt(8));
				
				productSearchProducerName.setProduct_Subcategory(subcategoryView);
				
				Supplier supplier=new Supplier();
				
				supplier.setSupplier_ID(rsSearchGlobal.getInt(9));
				
				productSearchProducerName.setProduct_Quantity(rsSearchGlobal.getInt(10));
				
				productSearchProducerName.setProduct_Rating(rsSearchGlobal.getInt(11));
				
			}
			
			
		} 
		
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		
		return productSearchProducerName;
	}
	
	
	public Product searchByCategory(String categoryName)
	{
		
		PreparedStatement pstmtProducerNamePreparedStatement=null;
		Product productSearchProducerName=null;

		System.out.println("In DAO Impl categoryName"+categoryName);
		
		String sqlNameSearch="SELECT * FROM product WHERE categ_id=(SELECT category_id FROM category WHERE category_name=?)";
		
		conn=getMySqlConnection();
		
		try
		{
			
			
			pstmtProducerNamePreparedStatement=conn.prepareStatement(sqlNameSearch);
			pstmtProducerNamePreparedStatement.setString(1,categoryName);
			
			ResultSet rsSearchGlobal=pstmtProducerNamePreparedStatement.executeQuery();
		
			while(rsSearchGlobal.next())
			{
				productSearchProducerName=new Product();
				
				productSearchProducerName.setProduct_ID(rsSearchGlobal.getInt(1));
				productSearchProducerName.setProduct_Name(rsSearchGlobal.getString(2));
				productSearchProducerName.setProduct_Description(rsSearchGlobal.getString(3));
				productSearchProducerName.setManufacturing_Date(rsSearchGlobal.getDate(4));
				productSearchProducerName.setManufacturing_Date(rsSearchGlobal.getDate(5));
				productSearchProducerName.setProduct_maximum_RetailPrice(rsSearchGlobal.getDouble(6));
				
				Category categoryView=new Category();
						
				categoryView.setCategory_ID(rsSearchGlobal.getInt(7));
				
				productSearchProducerName.setProduct_category(categoryView);
				
				SubCategory subcategoryView =new SubCategory();
		
				subcategoryView.setSub_category_ID(rsSearchGlobal.getInt(8));
				
				productSearchProducerName.setProduct_Subcategory(subcategoryView);
				
				Supplier supplier=new Supplier();
				
				supplier.setSupplier_ID(rsSearchGlobal.getInt(9));
				
				productSearchProducerName.setProduct_Quantity(rsSearchGlobal.getInt(10));
				
				productSearchProducerName.setProduct_Rating(rsSearchGlobal.getInt(11));
				
			}
			
			
		} 
		
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		
		return productSearchProducerName;
	}
	
	
	public Product searchBySubCategory(String subcategoryName)
	{
		
		PreparedStatement pstmtProducerNamePreparedStatement=null;
		Product productSearchProducerName=null;

		System.out.println("In DAO Impl categoryName"+subcategoryName);
		
		String sqlNameSearch="SELECT * FROM product WHERE sub_categry_id=(SELECT sub_category_id FROM sub_category WHERE sub_category_name=?)";
		
		conn=getMySqlConnection();
		
		try
		{
			
			
			pstmtProducerNamePreparedStatement=conn.prepareStatement(sqlNameSearch);
			pstmtProducerNamePreparedStatement.setString(1,subcategoryName);
			
			ResultSet rsSearchGlobal=pstmtProducerNamePreparedStatement.executeQuery();
		
			while(rsSearchGlobal.next())
			{
				productSearchProducerName=new Product();
				
				productSearchProducerName.setProduct_ID(rsSearchGlobal.getInt(1));
				productSearchProducerName.setProduct_Name(rsSearchGlobal.getString(2));
				productSearchProducerName.setProduct_Description(rsSearchGlobal.getString(3));
				productSearchProducerName.setManufacturing_Date(rsSearchGlobal.getDate(4));
				productSearchProducerName.setManufacturing_Date(rsSearchGlobal.getDate(5));
				productSearchProducerName.setProduct_maximum_RetailPrice(rsSearchGlobal.getDouble(6));
				
				Category categoryView=new Category();
						
				categoryView.setCategory_ID(rsSearchGlobal.getInt(7));
				
				productSearchProducerName.setProduct_category(categoryView);
				
				SubCategory subcategoryView =new SubCategory();
		
				subcategoryView.setSub_category_ID(rsSearchGlobal.getInt(8));
				
				productSearchProducerName.setProduct_Subcategory(subcategoryView);
				
				Supplier supplier=new Supplier();
				
				supplier.setSupplier_ID(rsSearchGlobal.getInt(9));
				
				productSearchProducerName.setProduct_Quantity(rsSearchGlobal.getInt(10));
				
				productSearchProducerName.setProduct_Rating(rsSearchGlobal.getInt(11));
				
			}
			
			
		} 
		
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		
		return productSearchProducerName;
	}
	
	
	
	

}
	 
	 
	

