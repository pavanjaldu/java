package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;


public class DiscountListJson extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		response.setContentType("text/html");
		//System.out.println(" Hello ");
		
		//Category List
		PrintWriter out=response.getWriter();
		IProductService serviceImpl=new ProductServiceImpl();
        List<Discount> discountListJson=serviceImpl.discountForProduct();
		
		Gson dobj=new Gson();
		
		String jsonObj=dobj.toJson(discountListJson);
		
		out.println(jsonObj);
		
		
		
		
		
		
		
	}

}
