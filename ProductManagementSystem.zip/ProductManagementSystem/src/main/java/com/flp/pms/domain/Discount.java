package com.flp.pms.domain;

import java.util.Date;

public class Discount
{


	private int discount_ID;
	private String discount_Name;
	private String discount_Description;
	private Double discount_Percentage;
	private Date valid_Thru;
	
	public Discount(){}
	
	
	public Discount(int discount_ID, String discount_Name, String discount_Description, Double discount_Percentage,
			Date valid_Thru) {
		super();
		this.discount_ID = discount_ID;
		this.discount_Name = discount_Name;
		this.discount_Description = discount_Description;
		this.discount_Percentage = discount_Percentage;
		this.valid_Thru = valid_Thru;
	}
	
		
	public int getDiscount_ID() {
		return discount_ID;
	}
	public void setDiscount_ID(int discount_ID) {
		this.discount_ID = discount_ID;
	}
	public String getDiscount_Name() {
		return discount_Name;
	}
	public void setDiscount_Name(String discount_Name) {
		this.discount_Name = discount_Name;
	}
	public String getDiscount_Description() {
		return discount_Description;
	}
	public void setDiscount_Description(String discount_Description) {
		this.discount_Description = discount_Description;
	}
	public Double getDiscount_Percentage() {
		return discount_Percentage;
	}
	public void setDiscount_Percentage(Double discount_Percentage) {
		this.discount_Percentage = discount_Percentage;
	}
	public Date getValid_Thru() {
		return valid_Thru;
	}
	public void setValid_Thru(Date valid_Thru) {
		this.valid_Thru = valid_Thru;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((discount_Description == null) ? 0 : discount_Description.hashCode());
		result = prime * result + discount_ID;
		result = prime * result + ((discount_Name == null) ? 0 : discount_Name.hashCode());
		result = prime * result + ((discount_Percentage == null) ? 0 : discount_Percentage.hashCode());
		result = prime * result + ((valid_Thru == null) ? 0 : valid_Thru.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Discount other = (Discount) obj;
		if (discount_Description == null) {
			if (other.discount_Description != null)
				return false;
		} else if (!discount_Description.equals(other.discount_Description))
			return false;
		if (discount_ID != other.discount_ID)
			return false;
		if (discount_Name == null) {
			if (other.discount_Name != null)
				return false;
		} else if (!discount_Name.equals(other.discount_Name))
			return false;
		if (discount_Percentage == null) {
			if (other.discount_Percentage != null)
				return false;
		} else if (!discount_Percentage.equals(other.discount_Percentage))
			return false;
		if (valid_Thru == null) {
			if (other.valid_Thru != null)
				return false;
		} else if (!valid_Thru.equals(other.valid_Thru))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Discount [discount_ID=" + discount_ID + ", discount_Name=" + discount_Name + ", discount_Description="
				+ discount_Description + ", discount_Percentage=" + discount_Percentage + ", valid_Thru=" + valid_Thru
				+ "]";
	}
	
	
	
	
	
	
}
