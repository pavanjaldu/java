package com.flp.pms.domain;

public class Supplier 
{

	private int supplier_ID;
	private String supplier_firstName;
	private String supplier_laststName; 
	private String supplier_Address;
	private String supplier_City;
	private String supplier_State;
	private String supplier_Pincode;
	private String supplier_Contact_Number;
	
	
	
	public Supplier(){}



	public int getSupplier_ID() {
		return supplier_ID;
	}



	public void setSupplier_ID(int supplier_ID) {
		this.supplier_ID = supplier_ID;
	}



	public String getSupplier_firstName() {
		return supplier_firstName;
	}



	public void setSupplier_firstName(String supplier_firstName) {
		this.supplier_firstName = supplier_firstName;
	}



	public String getSupplier_laststName() {
		return supplier_laststName;
	}



	public void setSupplier_laststName(String supplier_laststName) {
		this.supplier_laststName = supplier_laststName;
	}



	public String getSupplier_Address() {
		return supplier_Address;
	}



	public void setSupplier_Address(String supplier_Address) {
		this.supplier_Address = supplier_Address;
	}



	public String getSupplier_City() {
		return supplier_City;
	}



	public void setSupplier_City(String supplier_City) {
		this.supplier_City = supplier_City;
	}



	public String getSupplier_State() {
		return supplier_State;
	}



	public void setSupplier_State(String supplier_State) {
		this.supplier_State = supplier_State;
	}



	public String getSupplier_Pincode() {
		return supplier_Pincode;
	}



	public void setSupplier_Pincode(String supplier_Pincode) {
		this.supplier_Pincode = supplier_Pincode;
	}



	public String getSupplier_Contact_Number() {
		return supplier_Contact_Number;
	}



	public void setSupplier_Contact_Number(String supplier_Contact_Number) {
		this.supplier_Contact_Number = supplier_Contact_Number;
	}



	public Supplier(int supplier_ID, String supplier_firstName, String supplier_laststName, String supplier_Address,
			String supplier_City, String supplier_State, String supplier_Pincode, String supplier_Contact_Number) {
		super();
		this.supplier_ID = supplier_ID;
		this.supplier_firstName = supplier_firstName;
		this.supplier_laststName = supplier_laststName;
		this.supplier_Address = supplier_Address;
		this.supplier_City = supplier_City;
		this.supplier_State = supplier_State;
		this.supplier_Pincode = supplier_Pincode;
		this.supplier_Contact_Number = supplier_Contact_Number;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((supplier_Address == null) ? 0 : supplier_Address.hashCode());
		result = prime * result + ((supplier_City == null) ? 0 : supplier_City.hashCode());
		result = prime * result + ((supplier_Contact_Number == null) ? 0 : supplier_Contact_Number.hashCode());
		result = prime * result + supplier_ID;
		result = prime * result + ((supplier_Pincode == null) ? 0 : supplier_Pincode.hashCode());
		result = prime * result + ((supplier_State == null) ? 0 : supplier_State.hashCode());
		result = prime * result + ((supplier_firstName == null) ? 0 : supplier_firstName.hashCode());
		result = prime * result + ((supplier_laststName == null) ? 0 : supplier_laststName.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Supplier other = (Supplier) obj;
		if (supplier_Address == null) {
			if (other.supplier_Address != null)
				return false;
		} else if (!supplier_Address.equals(other.supplier_Address))
			return false;
		if (supplier_City == null) {
			if (other.supplier_City != null)
				return false;
		} else if (!supplier_City.equals(other.supplier_City))
			return false;
		if (supplier_Contact_Number == null) {
			if (other.supplier_Contact_Number != null)
				return false;
		} else if (!supplier_Contact_Number.equals(other.supplier_Contact_Number))
			return false;
		if (supplier_ID != other.supplier_ID)
			return false;
		if (supplier_Pincode == null) {
			if (other.supplier_Pincode != null)
				return false;
		} else if (!supplier_Pincode.equals(other.supplier_Pincode))
			return false;
		if (supplier_State == null) {
			if (other.supplier_State != null)
				return false;
		} else if (!supplier_State.equals(other.supplier_State))
			return false;
		if (supplier_firstName == null) {
			if (other.supplier_firstName != null)
				return false;
		} else if (!supplier_firstName.equals(other.supplier_firstName))
			return false;
		if (supplier_laststName == null) {
			if (other.supplier_laststName != null)
				return false;
		} else if (!supplier_laststName.equals(other.supplier_laststName))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Supplier [supplier_ID=" + supplier_ID + ", supplier_firstName=" + supplier_firstName
				+ ", supplier_laststName=" + supplier_laststName + ", supplier_Address=" + supplier_Address
				+ ", supplier_City=" + supplier_City + ", supplier_State=" + supplier_State + ", supplier_Pincode="
				+ supplier_Pincode + ", supplier_Contact_Number=" + supplier_Contact_Number + "]";
	}
	
	
	
	









}
