package com.flp.pms.domain;

import java.util.Date;
import java.util.List;

public class Product 
{

	//Product Instance Variables
	private int product_ID;
	private String product_Name;
	private String product_Description;
	private Date manufacturing_Date;
	private Date expiry_Date;
	private Double product_maximum_RetailPrice;
	private Category product_category;
	private SubCategory product_Subcategory;
	private Supplier product_Supplier;
	private List<Discount> product_Discount;
	private int product_Quantity;
	private float product_Rating;
	
	//No-Argument Constructor
	public Product(){}

    


	public Product(int product_ID, String product_Name, String product_Description, Date manufacturing_Date,
			Date expiry_Date, Double product_maximum_RetailPrice, Category product_category,
			SubCategory product_Subcategory, Supplier product_Supplier, List<Discount> product_Discount,
			int product_Quantity, float product_Rating) {
		super();
		this.product_ID = product_ID;
		this.product_Name = product_Name;
		this.product_Description = product_Description;
		this.manufacturing_Date = manufacturing_Date;
		this.expiry_Date = expiry_Date;
		this.product_maximum_RetailPrice = product_maximum_RetailPrice;
		this.product_category = product_category;
		this.product_Subcategory = product_Subcategory;
		this.product_Supplier = product_Supplier;
		this.product_Discount = product_Discount;
		this.product_Quantity = product_Quantity;
		this.product_Rating = product_Rating;
	}





	//Getters and Setters for Instance Variables of Product Class
	public int getProduct_ID() 
	{
		return product_ID;
	}



	public void setProduct_ID(int product_ID) {
		this.product_ID = product_ID;
	}



	public String getProduct_Name() {
		return product_Name;
	}



	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}



	public String getProduct_Description() {
		return product_Description;
	}



	public void setProduct_Description(String product_Description) {
		this.product_Description = product_Description;
	}



	public Date getManufacturing_Date() {
		return manufacturing_Date;
	}



	public void setManufacturing_Date(Date manufacturing_Date) {
		this.manufacturing_Date = manufacturing_Date;
	}



	public Date getExpiry_Date() {
		return expiry_Date;
	}



	public void setExpiry_Date(Date expiry_Date) {
		this.expiry_Date = expiry_Date;
	}



	public Double getProduct_maximum_RetailPrice() {
		return product_maximum_RetailPrice;
	}



	public void setProduct_maximum_RetailPrice(Double product_maximum_RetailPrice) {
		this.product_maximum_RetailPrice = product_maximum_RetailPrice;
	}



	public Category getProduct_category() {
		return product_category;
	}



	public void setProduct_category(Category product_category) {
		this.product_category = product_category;
	}



	public SubCategory getProduct_Subcategory() {
		return product_Subcategory;
	}



	public void setProduct_Subcategory(SubCategory product_Subcategory) {
		this.product_Subcategory = product_Subcategory;
	}



	public Supplier getProduct_Supplier() {
		return product_Supplier;
	}



	public void setProduct_Supplier(Supplier product_Supplier) {
		this.product_Supplier = product_Supplier;
	}



	public List<Discount> getProduct_Discount() {
		return product_Discount;
	}



	public void setProduct_Discount(List<Discount> product_Discount) {
		this.product_Discount = product_Discount;
	}



	public int getProduct_Quantity() {
		return product_Quantity;
	}



	public void setProduct_Quantity(int product_Quantity) {
		this.product_Quantity = product_Quantity;
	}


	public float getProduct_Rating() {
		return product_Rating;
	}





	public void setProduct_Rating(float product_Rating) {
		this.product_Rating = product_Rating;
	}




	



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((expiry_Date == null) ? 0 : expiry_Date.hashCode());
		result = prime * result + ((manufacturing_Date == null) ? 0 : manufacturing_Date.hashCode());
		result = prime * result + ((product_Description == null) ? 0 : product_Description.hashCode());
		result = prime * result + ((product_Discount == null) ? 0 : product_Discount.hashCode());
		result = prime * result + product_ID;
		result = prime * result + ((product_Name == null) ? 0 : product_Name.hashCode());
		result = prime * result + product_Quantity;
		result = prime * result + Float.floatToIntBits(product_Rating);
		result = prime * result + ((product_Subcategory == null) ? 0 : product_Subcategory.hashCode());
		result = prime * result + ((product_Supplier == null) ? 0 : product_Supplier.hashCode());
		result = prime * result + ((product_category == null) ? 0 : product_category.hashCode());
		result = prime * result + ((product_maximum_RetailPrice == null) ? 0 : product_maximum_RetailPrice.hashCode());
		return result;
	}









	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (expiry_Date == null) {
			if (other.expiry_Date != null)
				return false;
		} else if (!expiry_Date.equals(other.expiry_Date))
			return false;
		if (manufacturing_Date == null) {
			if (other.manufacturing_Date != null)
				return false;
		} else if (!manufacturing_Date.equals(other.manufacturing_Date))
			return false;
		if (product_Description == null) {
			if (other.product_Description != null)
				return false;
		} else if (!product_Description.equals(other.product_Description))
			return false;
		if (product_Discount == null) {
			if (other.product_Discount != null)
				return false;
		} else if (!product_Discount.equals(other.product_Discount))
			return false;
		if (product_ID != other.product_ID)
			return false;
		if (product_Name == null) {
			if (other.product_Name != null)
				return false;
		} else if (!product_Name.equals(other.product_Name))
			return false;
		if (product_Quantity != other.product_Quantity)
			return false;
		if (Float.floatToIntBits(product_Rating) != Float.floatToIntBits(other.product_Rating))
			return false;
		if (product_Subcategory == null) {
			if (other.product_Subcategory != null)
				return false;
		} else if (!product_Subcategory.equals(other.product_Subcategory))
			return false;
		if (product_Supplier == null) {
			if (other.product_Supplier != null)
				return false;
		} else if (!product_Supplier.equals(other.product_Supplier))
			return false;
		if (product_category == null) {
			if (other.product_category != null)
				return false;
		} else if (!product_category.equals(other.product_category))
			return false;
		if (product_maximum_RetailPrice == null) {
			if (other.product_maximum_RetailPrice != null)
				return false;
		} else if (!product_maximum_RetailPrice.equals(other.product_maximum_RetailPrice))
			return false;
		return true;
	}









	@Override
	public String toString() {
		return "Product [product_ID=" + product_ID + ", product_Name=" + product_Name + ", product_Description="
				+ product_Description + ", manufacturing_Date=" + manufacturing_Date + ", expiry_Date=" + expiry_Date
				+ ", product_maximum_RetailPrice=" + product_maximum_RetailPrice + ", product_category="
				+ product_category + ", product_Subcategory=" + product_Subcategory + ", product_Supplier="
				+ product_Supplier + ", product_Discount=" + product_Discount + ", product_Quantity=" + product_Quantity
				+ ", product_Rating=" + product_Rating + "]";
	}



		
}
