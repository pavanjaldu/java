package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;


public class ProductUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		System.out.println(" hello Product ");
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		Product prodModify=null;
		
		String productId=request.getParameter("productId");
		System.out.println("productId"+productId);
		
		IProductService serviceImpl=new ProductServiceImpl();
		
		
		prodModify=serviceImpl.modifyingProductFromDatabase(Integer.parseInt(productId));
		
		System.out.println(" hello "+prodModify.getManufacturing_Date());
		
		Gson dobj=new Gson();
		
		String jsonObj=dobj.toJson(prodModify);
		
		out.println(jsonObj);
		
		
	}

}
