package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;


public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Product productInsert=new Product();
		Category categoryInsert=new Category();
		SubCategory subCategoryInsert=new SubCategory();
		Supplier supplierInsert=new Supplier();
		Discount discountInsert=new Discount();
		IProductService serviceImpl=new ProductServiceImpl();
		
		response.setContentType("text/html");
		
		List<Discount> discountInsertList=new ArrayList<Discount>();
		
		SimpleDateFormat simpledateformat=new SimpleDateFormat("YYYY-MM-dd");
		
		//Getting from ProductViewPage
		String prodName=request.getParameter("prodName");
		String prodDesc=request.getParameter("prodDesc");
		String manufactDate=request.getParameter("manufactDate");
		String expiryDate=request.getParameter("expiryDate");
		String mrp=request.getParameter("mrp");
		String category=request.getParameter("category");
		String subcategory=request.getParameter("subcategory");
		String supplier=request.getParameter("supplier");
		String[] discount=request.getParameterValues("discount");
		String prodQuantity=request.getParameter("prodQuantity");
		String productRating=request.getParameter("productRating");
		
		for(String str:discount)
		{
			//System.out.println(" Discount list "+str);
			int discountToList=Integer.parseInt(str);
			discountInsert.setDiscount_ID(discountToList);
			discountInsertList.add(discountInsert);
		}
		
		
		/*System.out.println("prodName"+prodName);
		System.out.println("prodDesc"+prodDesc);
		System.out.println("manufactDate"+manufactDate);
		System.out.println("expiryDate"+expiryDate);
		System.out.println("mrp"+mrp);
		System.out.println("category"+category);
		System.out.println("subcategory"+subcategory);
		System.out.println("supplier"+supplier);*/
		
		for(String str:discount)
		{
			System.out.println(" Discount list "+str);
		}
		
		System.out.println("prodQuantity"+prodQuantity);
		System.out.println("productRating"+productRating);
	
	
		productInsert.setProduct_Name(prodName);
		productInsert.setProduct_Description(prodDesc);
		try
		{
			productInsert.setManufacturing_Date(simpledateformat.parse(manufactDate));
			productInsert.setExpiry_Date(simpledateformat.parse(expiryDate));
		} 
		catch (ParseException e) 
		{			
			e.printStackTrace();
		}
		
		productInsert.setProduct_maximum_RetailPrice(Double.parseDouble(mrp));
		//category Insert Object
		categoryInsert.setCategory_ID(Integer.parseInt(category));
		productInsert.setProduct_category(categoryInsert);
		//sub-category Insert
		subCategoryInsert.setSub_category_ID(Integer.parseInt(subcategory));
		productInsert.setProduct_Subcategory(subCategoryInsert);
	    //supplier Insert
		supplierInsert.setSupplier_ID(Integer.parseInt(supplier));
		productInsert.setProduct_Supplier(supplierInsert);
		
		//discountInsert.setDiscount_ID(discount_ID);
		productInsert.setProduct_Discount(discountInsertList);
		
		productInsert.setProduct_Quantity(Integer.parseInt(prodQuantity));
		productInsert.setProduct_Rating(Integer.parseInt(productRating));
	
		serviceImpl.insertionOfProduct(productInsert);
	}

}
