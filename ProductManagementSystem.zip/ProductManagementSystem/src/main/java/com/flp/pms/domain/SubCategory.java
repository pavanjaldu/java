package com.flp.pms.domain;

public class SubCategory
{
	
	
	//SubCategory Instance Variables
 private int sub_category_ID;
 private String sub_category_Name;	
 private Category category;
 


//No-Argument Constructor
public SubCategory(){}
 
//Full-Argument Constructor
public SubCategory(int sub_category_ID, String sub_category_Name, Category category) {
	super();
	this.sub_category_ID = sub_category_ID;
	this.sub_category_Name = sub_category_Name;
	this.category = category;
}

//Getters and Setters for Instance Variables of Product Class
public int getSub_category_ID() {
	return sub_category_ID;
}
public void setSub_category_ID(int sub_category_ID) {
	this.sub_category_ID = sub_category_ID;
}
public String getSub_category_Name() {
	return sub_category_Name;
}
public void setSub_category_Name(String sub_category_Name) {
	this.sub_category_Name = sub_category_Name;
}
public Category getCategory() {
	return category;
}
public void setCategory(Category category) {
	this.category = category;
}	
	
	
@Override
public String toString() {
	return "SubCategory [sub_category_ID=" + sub_category_ID + ", sub_category_Name=" + sub_category_Name
			+ ", category=" + category + "]";
}

//HashCode Method	
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((category == null) ? 0 : category.hashCode());
	result = prime * result + sub_category_ID;
	result = prime * result + ((sub_category_Name == null) ? 0 : sub_category_Name.hashCode());
	return result;
}


//Equals Method
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	SubCategory other = (SubCategory) obj;
	if (category == null) {
		if (other.category != null)
			return false;
	} else if (!category.equals(other.category))
		return false;
	if (sub_category_ID != other.sub_category_ID)
		return false;
	if (sub_category_Name == null) {
		if (other.sub_category_Name != null)
			return false;
	} else if (!sub_category_Name.equals(other.sub_category_Name))
		return false;
	return true;
}
	
	
}
