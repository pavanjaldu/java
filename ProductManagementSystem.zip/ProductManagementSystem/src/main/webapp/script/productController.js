app.controller('myCtrl', function($scope,$http) {
	
	
	
	var url='http://localhost:8080/ProductManagementSystem/CategoryDatabaseList';
  
	$http.get(url).success(function(response)
     {
		$scope.category=response;
		
		
        });
	
	$http.get(url).error(function(errMsg)
	{	
		console.log(errMsg);
	});
	
});