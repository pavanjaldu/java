package org.cap.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.login.pojo.Department;
import org.cap.login.pojo.Employee;
import org.cap.login.service.LoginService;
import org.cap.login.service.LoginServiceImpl;

/**
 * Servlet implementation class UpdateEmpServlet
 */
public class UpdateEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		int empId=Integer.parseInt(request.getParameter("employeeId"));
		String compEmail=getServletContext().getInitParameter("companyEmail");
		String complEmail=getServletConfig().getInitParameter("feedbckEmail");
		
		

		HttpSession session=request.getSession(true);
		String userName=(String)session.getAttribute("uname");
		
		
		LoginService loginService=new LoginServiceImpl();
		Employee emp=loginService.searchEmployee(empId);
		
		System.out.println(emp);
		
		out.println("<html><head><title>UpdateEmployee</title>"
				+ "<script type='text/javascript' src='script/myScript.js'></script>"
				+ "</head>"
				+ "<body>"
				+ "<form name='e1' method='post' action='UpdateEmployServlet' >");
		
		out.println("<h1 align='center'>Update Emplyee</h1><hr>");	
		
		out.println("<div style='margin-left:400px;'><b>Hello! <span>"+userName+" </span></b></div>");
		
		
		
		Cookie[] cookies=request.getCookies();
		for(Cookie ck:cookies)
			out.println(ck.getName() + "-->" + ck.getValue() + "<br>");
		
		out.println("<table style='margin-left:200px;border:1px solid black;'>"
				+ "<tr>"
				+ "<td>Employee Id</td>"
				+ "<td>"+emp.getEmpId()+"</td>"
						+ "<input type='hidden' name='employId' value='"+emp.getEmpId() +"'>" 
				+ "</tr>"
				+ "<tr>"
				+ "<td>FirstName</td>"
				+ "<td><input type='text' name='fname' value='" + emp.getFirstName()+"' size='20'>"
				+ "</tr>"
				
				+ "</tr>"
				+ "<tr>"
				+ "<td>lastName</td>"
				+ "<td><input type='text' name='lname' value='" + emp.getLastName()+"' size='20'>"
				+ "</tr>"
				
				
				+ "</tr>"
				+ "<tr>"
				+ "<td>email</td>"
				+ "<td><input type='text' name='email' value='" + emp.getEmail()+"' size='20'>"
				+ "</tr>"
				
				+ "</tr>"
				+ "<tr>"
				+ "<td>Emp salary</td>"
				+ "<td><input type='range' id='esal' name='empSalary' min='2000' value='" + emp.getSalary()+"' step='10000' max='500000' onchange='showSal()' >"
				+ "<div id='divSal'>"
				+emp.getSalary()
				+"</div></td></tr>"
				
				
				+ "</tr>"
				+ "<tr>"
				+ "<td>date of birth</td>"
				+ "<td><input type='date' name='empDob' value='" + emp.getEmpDob()+"' size='20'>"
				+ "</tr>"
				
				
				+ "</tr>"
				+ "<tr>"
				+ "<td>Date Of Joining</td>"
				+ "<td><input type='date' name='empDoj' value='" + emp.getEmpDoj()+"' size='20'>"
				+ "</tr>");
				
				String[] str = emp.getQualification().split(",");
			String status="checked";
				
			out.println( "</tr>"
				+ "<tr>"
				+ "<td>Qualification</td>"+ "<td>");
			
			if(str!=null){
			List<String> list = new ArrayList<String>();
			for(String s:str){
				list.add(s);
			}
				if(list.contains("BE"))
					out.println("<input type='checkbox' checked='checked' name='chkQualification' value='BE'> BE");
				else
					out.println("<input type='checkbox'  name='chkQualification' value='BE'> BE");
				
				if(list.contains("ME"))
					out.println("<input type='checkbox' checked='checked' name='chkQualification' value='ME'> ME");
				else
					out.println("<input type='checkbox'  name='chkQualification' value='ME'> ME");
				
				
				if(list.contains("MBA"))
					out.println("<input type='checkbox' checked='checked' name='chkQualification' value='MBA'> MBA");
				else
					out.println("<input type='checkbox'  name='chkQualification' value='MBA'> MBA");
				
				
				
				if(list.contains("BTECH"))
					out.println("<input type='checkbox' checked='checked' name='chkQualification' value='BTECH'> BTECH");
				else
					out.println("<input type='checkbox'  name='chkQualification' value='BTECH'>BTECH ");
				
				
				
				
			
					
			}
			
			
			
			out.println( "</td></tr>"
				
				
				
				+ "</tr>"
				+ "<tr>"
				+ "<td>Gender</td>");
			
			String gender=emp.getGender();
			
			
			out.println("<td>");
			
			if(gender.equalsIgnoreCase("male"))
				out.println("<input type='radio' name='gender' checked='checked' value='Male'>Male");
			else
				out.println("<input type='radio' name='gender'  value='Male'>Male");
			
			if(gender.equalsIgnoreCase("female"))
				out.println("<input type='radio' name='gender' checked='checked' value='Female'>Female");
			else
				out.println("<input type='radio' name='gender'  value='Female'>Female");
			
			
			
					
					out.println("</td>");
			
			
			
				 /*"<td><input type='text' name='empSalary' value='" + emp.getGender()+"' size='20'>"*/
				out.println( "</tr>");
				
				List<Department> departments=new ArrayList<>();
				
				departments.add(new Department(1,"Sales"));
				departments.add(new Department(2,"Purchase"));
				departments.add(new Department(3,"Finance"));
				departments.add(new Department(4,"Marketing"));
				
				int deptId=emp.getDepartment().getDepartmentId();
				out.println("</tr>"
				+ "<tr>"
				+ "<td>Departmen</td>"
				+ "<td><select name='empDepart'>");
				
				/*out.println("<option value='1' >Sales</option>"
				+"<option value='2'></option>"
				
				+"<option value='3' ></option>"
				
				+"<option value='4'></option>");
				*/
				String selected="";
				for(Department dep:departments){
					if( dep.getDepartmentId()==deptId){
						selected="selected";
					out.println("<option value='"+dep.getDepartmentId()+"' selected='"+selected+"' >"+dep.getDepartmentName()+"</option>");
					}
					else
					{
						out.println("<option value='"+dep.getDepartmentId()+"'  >"+dep.getDepartmentName()+"</option>");
					selected="";
					}
				}
				
				out.println("</select></td>"
				
				+ "</tr>"
				
				
				
				+ "</tr>"
				+ "<tr>"
				+ "<td>Address</td>"
				+ "<td><textarea rows='5' cols='20' name='empAddress' value='" + emp.getAddress()+"' size='20'></textarea>"
				+ "</tr>"
				
				
				+ "<tr>"
				+ "<td></td>"
				+ "<td><input type='submit' name='update' value='Update'>"
				+ "</tr>");
		
		
				
				
				out.println( "</table>"
						+ ""
						+ ""
						+ ""
						+ ""
						+ "<h2>Your Complaints are here: "+ complEmail+"</h2>"
						
						+ "<div style='margin-left:400px;font-weight:bold;'> Company : <i>"+ compEmail+"</i></div>"
						+ "</form></body></html>");
		
		
		
		
	
	}

}
