package org.cap.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UpdateEmployeeServlet
 */
public class UpdateEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String eid=request.getParameter("employId");
		
		PrintWriter out=response.getWriter();
		
		out.println("Employee Id: " + eid + " updated.");
		
		Cookie[] cookies=request.getCookies();
		for(Cookie ck:cookies)
			out.println(ck.getName() + "-->" + ck.getValue() + "<br>");

		HttpSession session=request.getSession(true);
		String userName=(String)session.getAttribute("uname");
		
		
		out.println("<div style='margin-left:400px;'><b>Hello! <span>"+userName+" </span></b></div>");
		
		
	}

}
