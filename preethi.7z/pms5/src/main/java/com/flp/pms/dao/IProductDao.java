package com.flp.pms.dao;

import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public interface IProductDao {

	public List<Category> getAllCategory();

	public List<SubCategory> getAllSubCategory();

	public List<Supplier> getAllSuppliers();

	public List<Discount> getAllDiscounts();

	public void addProduct(Product product);

	public Map<Integer, Product> getAllProducts();
	public List<Product> getAllProducts1();
	public void updateProductName(Product product,String productName);
	public void updateProductMaxRetailPrice(Product product,double max_price);
	public void updateProductExpiryDate(Product product, java.util.Date expiryDate);
	public void updateProductRating(Product product, float rating);

	public void updateProductCategory(Product product, Category category);
	public void deleteProduct(int productId);
	public void storeJsonData(String namejson);
	public String getJsonData();

	
	
}
/*  

public boolean productUpdateAll(String prodName,String prodDesc,int prodSupp,int prodQuan, Float rating,int prod_id)
	{
       String sqlratingsUpdate="UPDATE product SET  prod_Name=?,prod_decription=?,supplirId=?,prod_Quanty=?,prod_rating=? WHERE prod_Id=?";
		
		conn=getMySqlConnection();
		
		try
		{
			PreparedStatement ptsmtrating=conn.prepareStatement(sqlratingsUpdate);
			
			
			ptsmtrating.setString(1,prodName);
			ptsmtrating.setString(2,prodDesc);
			ptsmtrating.setInt(3,prodSupp);
			ptsmtrating.setInt(4,prodQuan);
			ptsmtrating.setFloat(5,rating);
			ptsmtrating.setInt(6,prod_id);
			
			int ratingupdated=ptsmtrating.executeUpdate();
			
			if(ratingupdated>0)
					return true;
			
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;	
		
	}*/
	
