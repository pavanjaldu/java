function validate()
{
	var pnm=pname();
	var pdec=pdescription();
	
	
	
	//return true;
}

function pname()
{
	var nm=document.getElementById('pname').value;
	 
	 if(nm=='')
	{ 
		document.getElementById("pnmerror").innerHTML="Put ProductName!!! ";
		return false;
	} 
	return true;
}
function pdescription()
{
	if(document.getElementById('pdescription').value=='')
	{ 
		document.getElementById("pdeserror").innerHTML="Put Description!!!";
		return false;
	}
	return true;
}