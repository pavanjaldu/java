package com.cgp.database;

import java.util.Date;
import java.util.List;

import com.cgp.domain.Category;
import com.cgp.domain.Discount;
import com.cgp.domain.Product;
import com.cgp.domain.SubCategory;
import com.cgp.domain.Supplier;

public interface DataBaseInter {
	public List<Category> getAllCategory();
	public List<SubCategory> getAllSubCategory();
	public List<Discount> getAllDiscounts();
	public List<Supplier> getAllSupplier();
	 public List<Product> getAllProducts();
	 public boolean updateProductName(Product uproduct,String name);
	 public boolean updateProductPrice(Product uproduct,double price);
	 public boolean updateProductDescription(Product uproduct,String name);
	 public boolean updateProductExpDate(Product uproduct,Date expDate);
	 public boolean updateProductCategory(Product uproduct, Category category);
	 public void storeJsonData(String prodidjson);
	 public String getJsonData();
	 public boolean removeProduct(int productId);

}
