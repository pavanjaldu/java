package com.cgp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cgp.database.DataBase;
import com.cgp.domain.Discount;
import com.cgp.domain.Product;
import com.cgp.service.IProductService;
import com.cgp.service.ProductServiceImpl;
import com.google.gson.Gson;
 
public class SearchSucessfully extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//DataBase db=new DataBase();
		PrintWriter out=response.getWriter();
		Gson myjson=new Gson();
		IProductService iProductService=new ProductServiceImpl();
		 String category=request.getParameter("menu");
		 String value=request.getParameter("search");
		 if(category.equalsIgnoreCase("id"))
		 {
			Product product= iProductService.searchProductById(Integer.parseInt(value));
			 String jsoninput=myjson.toJson(product);
			 iProductService.storeJsonData( jsoninput);
			 response.sendRedirect("pages/Search.html");
		 }
		 else if(category.equalsIgnoreCase("name"))
		 {
			 Product product= iProductService.searchProductName(value);
			 String jsoninput=myjson.toJson(product);
			 iProductService.storeJsonData( jsoninput);
			 response.sendRedirect("pages/Search.html");
		 }
		 else if(category.equalsIgnoreCase("supplier"))
		 {
			 Product product= iProductService.searchProductBySupplier(value);
			 String jsoninput=myjson.toJson(product);
			 iProductService.storeJsonData( jsoninput);
			 response.sendRedirect("pages/Search.html");
		 }
		 else if(category.equalsIgnoreCase("category"))
		 {
			 Product product= iProductService.searchProductByCategory(value);
			 String jsoninput=myjson.toJson(product);
			 iProductService.storeJsonData( jsoninput);
			 response.sendRedirect("pages/Search.html");
		 }
		 else{}
		/* DataBase db=new DataBase();
		 Product pro=new Product();
		 List<Product> product=db.getAllProducts();
		 for (Product product2 : product) {
			if(product2.getProductId()==Integer.parseInt(value))
				pro=product2;
		}
		 Gson myJson=new Gson();
		 String discount=myJson.toJson(pro);
		 out.println(pro);*/
		 
		 
		 
	}

}
