package com.cgp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cgp.database.DataBase;
import com.cgp.domain.Category;
import com.cgp.domain.Discount;
import com.cgp.domain.Product;
import com.cgp.domain.SubCategory;
import com.cgp.domain.Supplier;
 
public class UpdateView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   
		DataBase db=new DataBase();
	    List<Product>productList=db.getAllProducts();
	    List<Category>categoryList=db.getAllCategory();
	    List<SubCategory>subcategoryList=db.getAllSubCategory();
	    List<Supplier>supplierList=db.getAllSuppliers();
	    List<Discount>discountList=db.getAllDiscounts();
	    SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
	    PrintWriter out=response.getWriter();
	    out.println("<html><head><title>Product Details</title></head><body>"
				+ "<h1 align='center'>Product Details</h1>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Product Id</th>"
				+ "<th>Praduct Name</th>"
				+ "<th>Product Description </th>"
				+ "<th>MFD Date</th>"
				+ "<th>Exp Date</th>"
				+ "</tr>");
	    for (Product product : productList) {
	    	out.println("<tr>"
					+ "<td>"+product.getProductId()+"</td>"
							+ "<td>"+product.getProductName()+"</td>"
									+ "<td>"+product.getDescription()+"</td></tr>");
	    	if(product.getManufacturing_date()!=null)
				out.println("<td>"+myFormat.format(product.getManufacturing_date())+"</td>");
			else
				out.println("<td>  </td>");
		
			if(product.getExpiry_date()!=null)	
				out.println("<td>"+myFormat.format(product.getExpiry_date())+"</td>");									
			else
				out.println("<td>  </td>");
			  out.println("<th>Product MRP</th>"
						+ "<th>Quantaty</th>"
						 + "</tr>");
			  out.println("<tr>"
						+ "<td>"+product.getMax_retail_price()+"</td>"
								+ "<td>"+product.getQuantity()+"</td>");
			  out.println("<th>Category</th>"
					   + "</tr>");
			  for (Category category : categoryList)  
				  if(category.getCategory_Id()==product.getCategory().getCategory_Id())
					  out.println("<tr>"
								+ "<td>"+category.getCategory_Name()+"</td>"); 
			  out.println("<th>SubCategory</th>"
					   + "</tr>");
			  for (SubCategory subcategory : subcategoryList) 
				  if(subcategory.getSub_category_Id()==product.getSubCategory().getSub_category_Id())
					  out.println("<tr>"
								+ "<td>"+subcategory.getSub_category_Name()+"</td>");
				
			 
			  out.println("<th>Discount</th>"
					   + "</tr>");
			  out.println("</table><body></html>");
			  
		 /*  for (Discount discount : discountList) {
				  if(discount.getDiscountId()==product.getDiscounts().)
				
			}
			  
			  
			  out.print("<th>Supplier</th>"
					   + "</tr>");
		 for (Supplier supplier : supplierList) {
			 if(supplier.getSupplierId()==product.getSupplier().getSupplierId())
				 out.println("<tr>"
							+ "<td>"+supplier.getFirstName()+"</td>");
			
		}*/
					
	 
 
			 
			 
		}
	}
   

}
