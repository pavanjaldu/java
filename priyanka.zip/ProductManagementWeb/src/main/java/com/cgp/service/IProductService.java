package com.cgp.service;

 

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.cgp.domain.Category;
import com.cgp.domain.Discount;
import com.cgp.domain.Product;
import com.cgp.domain.SubCategory;
import com.cgp.domain.Supplier;

 

public interface IProductService {
	public List<Category> getAllCategory();
	public List<SubCategory> getAllSubCategory();
	public List<Discount> getAllDiscounts();
	public List<Supplier> getAllSupplier();
	 public List<Product> getAllProducts();
	public Product searchProductName(String productName);
	public Product searchProductBySupplier(String supplierName);
	public Product searchProductBySubCategory( String subcatName);
	public Product searchProductByCategory(String catName);
	public Product searchProductById(int productId);
	public void storeJsonData(String prodidjson);
	public String getJsonData();
	public boolean removeProduct(int productId);
	 
	 
}
