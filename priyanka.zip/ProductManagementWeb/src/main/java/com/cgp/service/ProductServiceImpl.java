package com.cgp.service;

 

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cgp.database.DataBase;
import com.cgp.database.DataBaseInter;
import com.cgp.domain.Category;
import com.cgp.domain.Discount;
import com.cgp.domain.Product;
import com.cgp.domain.SubCategory;
import com.cgp.domain.Supplier;
 

public class ProductServiceImpl implements IProductService {

	private  DataBaseInter iProductDao = new DataBase();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Discount> getAllDiscounts() {

		return iProductDao.getAllDiscounts();
	}

	public List<Supplier> getAllSupplier() {

		return iProductDao.getAllSupplier();
	}

	 
	public Product searchProductName(String productName) {
		List<Product> productList = getAllProducts();
		Product searchProduct = null;
		for (Product product : productList) {
			if (product.getProductName().equalsIgnoreCase(productName)) {
				searchProduct = product;
			}
		}
		return searchProduct;
	}
	 
	 

	public Product searchProductBySupplier(String supplierName) {
		List<Product> productList = getAllProducts();
		Product searchSupplier = null;
		for (Product product : productList) {
			if(product.getSupplier().getFirstName().equalsIgnoreCase(supplierName))
				searchSupplier=product;
		 }
		return searchSupplier;
	}

	public Product searchProductBySubCategory(String subcatName) {
		List<Product> productList = getAllProducts();
		Product searchSubCategory = null;
		for (Product product : productList) {
			if(product.getSubCategory().getSub_category_Name().equalsIgnoreCase(subcatName))
				searchSubCategory=product;
		}
		return searchSubCategory;
	}

	public Product searchProductByCategory(String catName) {
		List<Product> productList = getAllProducts();
		Product searchCategory = null;
		for (Product product : productList) {
			if(product.getCategory().getCategory_Name().equalsIgnoreCase(catName))
				searchCategory=product;
		}
		return searchCategory;
	}

	 

	public Product searchProductById(int productId) {
		 List<Product>products=getAllProducts();
		 Product searchProduct=null;
		 for (Product product : products) {
			 if(product.getProductId()==productId)
				 searchProduct=product;
			
		}
		return searchProduct;
	}
 

	public List<Product> getAllProducts() {
	  return  iProductDao.getAllProducts(); 
		 
	}

	@Override
	public void storeJsonData(String prodidjson) {
		 iProductDao.storeJsonData(prodidjson);
		
	}

	@Override
	public String getJsonData() {
		return iProductDao.getJsonData();
	}

	@Override
	public boolean removeProduct(int productId) {
		System.out.println(iProductDao. removeProduct(productId));
				return iProductDao. removeProduct(productId);
	 
	}

	 

	 

	 
	 
}
